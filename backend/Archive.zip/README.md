# Fitness_App
This is a fitness app the calculates how far someone runs along with how many calories they burn
